// Function to remove unwanted elements
function removeUnwantedElements() {
  // Remove all <a> elements with target="_blank"
  document.querySelectorAll('a').forEach(link => {
    if (link.getAttribute('target') === '_blank') {
      link.remove();
    }
  });

  // Remove <span> elements that are advertising badges
  document.querySelectorAll('span.jsx-1055761795.Badge.Badge-advertisement.Badge-transparent').forEach(span => {
    if (span.textContent.includes('Anzeige')) {
      span.remove();
    }
  });

  // Remove <div> elements with id="banner-skyscraper" and class="sticky-advertisement"
  document.querySelectorAll('div#banner-skyscraper.sticky-advertisement').forEach(div => {
    div.remove();
  });

  // Remove <div> elements with id="lsrp-sky-atf-left" and class="l-container liberty-filled"
  document.querySelectorAll('div#lsrp-sky-atf-left.l-container.liberty-filled').forEach(div => {
    div.remove();
  });

  document.querySelectorAll('div#jsx-2023474509 skyscraper-header-container').forEach(div => {
    div.remove();
  });
  document.querySelectorAll('div#jsx-2023474509 skyscraper-container').forEach(div => {
    div.remove();
  });

  document.querySelectorAll('img[loading="lazy"]').forEach(img => {
    if (img.getAttribute('fetchpriority') !== 'low') {
      img.remove();
    }
  });
}

// Initial cleanup when the page loads
removeUnwantedElements();

// Set up a Mutation Observer to monitor changes to the DOM
const observer = new MutationObserver(() => {
  removeUnwantedElements();
});

// Start observing the document body for changes
observer.observe(document.body, {
  childList: true, // Watch for added/removed child nodes
  subtree: true    // Watch the entire subtree of the body
});
